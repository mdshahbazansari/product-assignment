import Signup from '@/components/Signup'
import React from 'react'

const page = () => {
  return (
    <div>
      <Signup />
    </div>
  )
}

export default page
