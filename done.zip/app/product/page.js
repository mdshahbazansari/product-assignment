import Product from '@/components/Product'
import React from 'react'

const page = () => {
  return (
    <div>
      <Product />
    </div>
  )
}

export default page
